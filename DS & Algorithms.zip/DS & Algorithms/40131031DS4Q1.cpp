#include<bits/stdc++.h>

using namespace std;

int main()
{
    string parentheses;
    cin >> parentheses;
    int mis = 0;
    int check = 0;
    for (int i = 0; i < parentheses.size(); i++)
    {
        if (parentheses[i] == '(')
            check += 1;
        else check -= 1;
        if (check < 0)
        {
            mis += 1;
            check = 1;
        }
    }
    mis += int(check / 2);
    cout << mis;
    return 0;
}
