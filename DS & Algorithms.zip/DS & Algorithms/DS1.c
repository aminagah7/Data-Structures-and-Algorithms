#include <stdio.h>
#define MIN(i, j) (((i) < (j)) ? (i) : (j))
#define MAX(i, j) (((i) > (j)) ? (i) : (j))
int main(){
    int n , m , tempr , templ;
    scanf("%d%d" , &n ,&m);
    int r[30],l[30];
    for(int i = 0 ; i<n+m ; i++){
        scanf("%d%d", &templ ,&tempr);
        l[i] = templ;
        r[i] = tempr;
    }
    int days = 0;
    for(int j = 0 ; j<m+n ; j++ ){
        for(int k = j+1 ; k<m+n ; k++){
            if(( l[j]<=l[k] && r[j]>=l[k]) || (l[k]<=l[j] && r[k]>=l[j]))
                days += MIN(r[j],r[k])- MAX(l[j],l[k]) + 1;
        }
    }
    printf("%d",days);
    return 0;
}