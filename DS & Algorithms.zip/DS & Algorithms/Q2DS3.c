#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<string.h>

int main(){
    int H;
    char c[35];
    scanf("%d %s", &H, c);

    int sz = strlen(c);
    int x = 1;
    for (int i = 0; i < sz; i++) {
        if (c[i] == 'L')
            x = 2 * x;
        else
            x = 2 * x + 1;
        // printf("check = %d = %c = %d , %d\n", i, c[i], x, H);
    }

    printf("%d\n", (1 << H + 1) - x);
}